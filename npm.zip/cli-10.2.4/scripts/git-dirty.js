const { run, git } = require('./util.js')

run(git.dirty)
