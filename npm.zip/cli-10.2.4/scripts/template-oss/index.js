module.exports = {
  ...require('./branch-specific-config.js'),
}
