# peer optional failure c

```
root -> (x) PEEROPTIONAL(y@1)
x -> PEER(z)
z -> PEEROPTIONAL(y@2)
```

[npm/arborist#223](https://github.com/npm/arborist/issues/223)
