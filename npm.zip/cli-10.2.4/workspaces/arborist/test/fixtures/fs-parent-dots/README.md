Run a buildIdealTree in ./x/y/z, make sure that `../..` is the fsParent of
the things it should be.
